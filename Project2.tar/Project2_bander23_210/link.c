#include "link.h"



ListNode *newList()
// make a new list with a dummy head
{
  ListNode *dummy;
  dummy = malloc(sizeof(ListNode));
  dummy->next = NULL;
  return dummy;
  }

void printList(ListNode *head)
// print the list
{
  ListNode *curr;
  curr = head;
  int len = 0;
  while (curr !=NULL)
    {
      if (len == 8)
	{
	  printf("\n"); len = 0;
	}
      printf("%10d ",curr->num);
      len++;
      curr = curr->next;
    }
  printf("\n");
}
ListNode *insert_tail(ListNode *tail, int target)             // insert and element at tail
{
tail -> num = target;
return tail;
}
ListNode *insert_tail_node(ListNode *tail, ListNode *node) // insert node at tail
{
tail = node;
return tail;
}
ListNode *delete(ListNode *prev)                           // deletes the node after previous
{
free(prev -> next);
return prev;
}
void deleteList(ListNode *head)                            // delete the entire list
{
ListNode *ptr = head -> next;
ptr = ptr -> next;
free(ptr);
}

ListNode *find(ListNode *head, int target)                    // find the position of the prev node for num
{
ListNode *ptr = head -> next;
while(ptr && ptr -> num != target)
ptr = ptr -> next;
return ptr;
}

