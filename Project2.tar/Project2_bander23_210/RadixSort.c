//Brian Anderson G00986738
//CS 262 Section 210
//Project2

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "link.h"

int main(int argc, char *argv[])
{
	//all variables to use within main
	int i=0,j=0,exp=0;	//counters
	int seed = atoi(argv[1]);	//seed
	int N = atoi(argv[2]);		//number of trials
	int low = atoi(argv[3]);	//min random number
	int high = atoi(argv[4]);	//max random number
	int rand;			//rand value
	int val=0;			//value placeholder
	int exponent = 1;		//10 to the power of exponent
	int numdiv = 0;			//number of divisions to get 0
	int store = 0;			//holds value for mod
	int tempnum = 1;		//temp counter
	if( high<=low || argc != 5 || high > 1000)	//if invalid command line args exit program
	{
		printf("Error invalid inputs\n");
		exit(1);
	}	
	srandom(seed);	//seed random number generator
	ListNode *bucketlist[10][N],*head,*tail,*current,*temp[N],*buckettail,*values[N];	//all the nodes

	//initialize all nodes
	head = malloc(sizeof(ListNode));
	tail = malloc(sizeof(ListNode));
	buckettail = malloc(sizeof(ListNode));
	*values = head;
	*temp = head;
	**bucketlist = head;

	//loop to initialize values of bucketlist
	for(i=0;i<10;i++)
	{
		for(j=0;j<N+1;j++)
		{
			bucketlist[i][j] = newList();
			bucketlist[i][j] -> num = 0;
			bucketlist[i][j] -> next =  bucketlist[i][j];
		}
		//printf("List: %d\n",bucketlist -> num);
		if(i == 9)
		{
			**bucketlist = buckettail;
			buckettail -> next = NULL;
		}
	}
	//initialize tail to end of temporary list
	temp[N]=tail;
	tail -> next = NULL;

	//generates random number and inserts it into node. Inserts node into list at tail
	bucketlist[0][0] -> num = 0;
	for(i=0;i<N;i++)
	{
		rand = random()%high;
		current = newList();
		current -> num = rand;
		current -> next = current;
		temp[i] = current;
		temp[i]=insert_tail_node(tail,current);
		//printf("tail %d \n",temp[i] -> num);
		printf("Digit: %d List: %d\n",i,current -> num);
		values[i] = newList();
		values[i] -> next = values[i];
	}

	//sorts list for 10
	for(i=0;i<N;i++)
	{
		val = temp[i] -> num;
		val = val%10;
		while(bucketlist[val][tempnum] -> num != 0)
			tempnum ++;
		//printf("%d\n",val);
		bucketlist[val][tempnum] -> num = temp[i] -> num;

		while(bucketlist[val][tempnum] -> num < bucketlist[val][tempnum-1] -> num && tempnum > 0)
		{
			bucketlist[val][tempnum] -> num = bucketlist[val][tempnum-1] -> num;
			bucketlist[val][tempnum-1] -> num = temp[i] -> num;
			tempnum--;
		}
		tempnum = 1;
	}
	//clean list
	for(i=0;i<10;i++)
	{
		for(j=0;j<N;j++)
		{
			if(bucketlist[i][j] -> num !=0)
			{
				//printf(" %d ", bucketlist[i][j] -> num);
				temp[exp] -> num  = bucketlist[i][j] -> num;
				bucketlist[i][j] -> num = 0;
				exp++;
			}
		}
		//printf("\n");
	}
	//printf("\n");
	//sort for 100
	for(i=0;i<N;i++)
	{
		val = temp[i] -> num;
		store = val;
		exponent = 10;
		numdiv = 1;
		while(store>10)
		{
			store = store%10;
			exponent = exponent*10;
			numdiv++;
		}
		val = (val%100)/10;

		while(bucketlist[val][tempnum] -> num != 0)
			tempnum ++;
		//printf("%d\n",val);
		bucketlist[val][tempnum] -> num = temp[i] -> num;

		while(bucketlist[val][tempnum] -> num < bucketlist[val][tempnum-1] -> num && tempnum > 0)
		{
			bucketlist[val][tempnum] -> num = bucketlist[val][tempnum-1] -> num;
			bucketlist[val][tempnum-1] -> num = temp[i] -> num;
			tempnum--;
		}
		values[i] -> num  = temp[i] -> num;
		tempnum = 1;
	}
	exp = 0;
	for(i=0;i<10;i++)
	{
		for(j=0;j<N;j++)
		{
			if(bucketlist[i][j] -> num !=0)
			{
				temp[exp] -> num  = bucketlist[i][j] -> num;
				//printf(" %d ", temp[j] -> num);
				bucketlist[i][j] -> num = 0;
				exp++;
			}
		}
	}
	printf("\n");
	//sort for 1000
	for(i=0;i<N;i++)
	{
		val = temp[i] -> num;
		store = val;
		exponent = 10;
		numdiv = 1;
		while(store>10)
		{
			store = store%10;
			exponent = exponent*10;
			numdiv++;
		}
		val = (val%1000)/100;

		while(bucketlist[val][tempnum] -> num != 0)
		tempnum ++;
		//printf("%d\n",val);
		bucketlist[val][tempnum] -> num = temp[i] -> num;

		while(bucketlist[val][tempnum] -> num < bucketlist[val][tempnum-1] -> num && tempnum > 0)
		{
			bucketlist[val][tempnum] -> num = bucketlist[val][tempnum-1] -> num;
			bucketlist[val][tempnum-1] -> num = temp[i] -> num;
			tempnum--;
		}
		values[i] -> num  = temp[i] -> num;
		tempnum = 1;

		//printf(" %d ", temp[i] -> num);
	}
	printf("\n");
	//output final list
	for(i=0;i<10;i++)
	{
		printf("%d",i);
		for(j=0;j<N;j++)
		{
			if(bucketlist[i][j] -> num != 0)
			printf(" %d ", bucketlist[i][j] -> num);
		}
		printf("\n");
	}
	//free remaining memory
	free(*values);
	free(*temp);
	free(**bucketlist);
	free(head);
	free(tail);
	return 0;
}


