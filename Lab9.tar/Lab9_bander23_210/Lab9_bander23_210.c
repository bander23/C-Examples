//Brian Anderson G00986738
//CS 262 Section 210
//Lab9
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct num
{
	int randnum;
	struct num *next;
}num;

void insertNodeSorted(num *head, num *current)
{
num *temp;
temp = malloc(sizeof(num));
while(current -> randnum > current -> next -> randnum)
{
head -> next = head;
}
current = head;
free(temp);
}

void printList(num *head)
{
printf("Number is: %d\n",head -> randnum);
head -> next = head;
}

void deleteList(num *head)
{
do
{
head -> next = head;
free(head);
}
while(!head);
printf("List clear\n");
}

int main(int argc, char *argv[])
{
int seed =(int)*argv[1];
int max =(int)*argv[3];
srandom(seed);
num *head,*current; 
num *dummy;
int i,rand;
dummy = malloc(sizeof(num));
head = malloc(sizeof(num));
current = head;
if(argc != 4)
{
exit(1);
}
for(i=0;i<*argv[2];i++)
{
do
{
rand = random()%max/2;
}while(rand > max);
printf("Number: %d\n",rand);
current -> randnum = rand;
current -> next = current;
insertNodeSorted(head,current);
current = head;
printList(head);
}

deleteList(current);
free(dummy);
return 0;
}
