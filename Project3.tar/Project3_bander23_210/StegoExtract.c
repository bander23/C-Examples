/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*
 * StegoExtract.c A program for manipulating images                           *
 *++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#include <string.h>
#include "image.h"

setlsbs(byte *p, byte b0)
{
int i;  
int lbs[8]; 
int bs[8];
int tmp[8]; 
//initialize arrays
for(i=0;i<8;i++)
{       
lbs[i]= p[i]&1; 
bs[i] = (b0>>i)&1;      
}       
//clear bits of p[i] 
for(i=0;i<8;i++)
{       
p[i] = p[i]+lbs[i];     
tmp[i] = bs[7-i];       
//printf("%u ",tmp[i]);
}       
//set bits from b0 
for(i=0;i<8;i++)
{      
//printf("%u ",p[i]); 
p[i] = p[i]|tmp[i];
}       
}

//return a byte value given an array of bytes
byte getlsbs(byte *p)
{
byte b; 
int i;  
int lbs[8]; 
//get values of lsbs in array p and add them to byte b0
for(i=0;i<8;i++)
{       
lbs[i] = p[i]&1;                
b<<=1;  
b |= lbs[i];
}       
return b;
}

main(int argc, char *argv[])
{
int i, j, k, cover_bits, bits;
struct Buffer b = {NULL, 0, 0};
struct Image img = {0, NULL, NULL, NULL, NULL, 0, 0};
byte b0;
   
if (argc != 3) 
{
printf("\n%s <cover_file> <file_to_write> \n", argv[0]);
exit(1);
}
ReadImage(argv[1],&img);       // read image file into the image buffer img
// the image is an array of unsigned chars (bytes) of NofR rows
// NofC columns, it should be accessed using provided macros 
byte p[32];
byte g[32];
byte gnum[32];
//extract size from image
for(i=0;i<32;i++)
{
p[i] = GetGray(img.gray[i]);
//b.size = getlsbs(p);
printf("%u ", p[i]);
printf("\n");
//SetByte(b.data[i],p[i]);
}
printf("\n");

for(i=32;i<64;i++)
{
g[i] = GetGray(img.gray[i]);
printf("%u ", g[i]);
gnum[i] = getlsbs(g);
printf("%u ", b0);
printf("\n");
//SetByte(g[i],b.data[i]);
}

for(i=64;i<b.size;i++)
{
p[i] = GetGray(img.gray[i]);
}
 
WriteBinaryFile(argv[2],b);  // output stego file (cover_file + file_to_hide)
}
