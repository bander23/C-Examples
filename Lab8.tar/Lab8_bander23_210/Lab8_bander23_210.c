//Brian Anderson G00986738
//CS 262 Section 210
//Lab8

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

typedef struct Location
{
char locationname[35];
char description[85];
double latitude;
double longitude;
}Location;

Location resizeArray(int size, Location *locationArray)
{
Location tempArray[size*2];
int i;
int *bad = malloc(size*2*sizeof(locationArray));
if(bad == NULL)
{
printf("Out of memory /n");
exit(1);
}
memcpy(tempArray,locationArray,size);
for(i=0;i<size;i++)
{
	tempArray[i] = locationArray[i];
}
free(*&locationArray);
return *tempArray;
}

int addLocation(Location *locationArray,int count,int size, FILE *input)
{
if(size<=count-1)
{
*locationArray = resizeArray(size,locationArray);
size = size*2;
}
printf("Please input data for new Location \n");
printf("Location Name: \n");
if(input != NULL)
fgets(locationArray[count].locationname,size,input);
else
scanf("%s", locationArray[count].locationname);
printf("Description: \n");
if(input != NULL)
fgets(locationArray[count].description,size,input);
else
scanf("%s", locationArray[count].description);
printf("Latitude: \n");
if(input != NULL)
locationArray[count].latitude = fgetc(input);
else
scanf("%lf",&locationArray[count].latitude);
printf("Longitude: \n");
if(input != NULL)
locationArray[count].longitude = fgetc(input);
else
scanf("%lf",&locationArray[count].longitude);

return size;
}

void printAll(Location *locationArray,int size)
{
int i;
for(i=0;i<size+1;i++)
{
	printf("Location Name %s \n",locationArray[i].locationname);
	printf("Description: %s \n",locationArray[i].description);
	printf("Latitude: %lf \n", locationArray[i].latitude);
	printf("Longitude: %lf \n", locationArray[i].longitude);
}

}

int main(int argc, char *argv[])
{
FILE *input;
char choice;
int numLocations;
int *bad;
int count = 0;
input = fopen(argv[1], "r");
assert(input != NULL);

printf("Enter the number of locations: \n");
if(argv[1] != NULL)
numLocations = fgetc(input);
else
scanf("%d",&numLocations);

Location locationArray[numLocations];
bad =malloc(numLocations*sizeof(Location));
if(bad==NULL)
{
printf("Error out of memory \n");
exit(1);
}

while(choice != -1 )
{
if(argv[1] != NULL)
{
choice = fgetc(input);
}
else
{
printf("Select a choice from the menu: \n");
printf("A - Add additional locations to the LocationArray \n");
printf("P - Print the current list of locations (print all elements of each location struct \n");
printf("Q - Quit the program \n");
if(argv[1] != NULL)

scanf("%s",&choice);
}

if(choice=='a' || choice=='A')
{
numLocations = addLocation(locationArray,count,numLocations,input);
count++;
}
else if(choice=='p' || choice=='P')
{
printAll(locationArray,numLocations);
}
else if(choice=='q' || choice=='Q')
{
printf("Program will exit now \n");
exit(1);
}
else
{
printf("Improper input. Try again. \n");
}
}
return 0;
}

