//Brian Anderson G00986738
//CS 262, Lab Section 210
//Lab3

#include <stdio.h>
#include <stdlib.h>

void  printMenu()
{
printf("To enter a character press C or c \n");
printf("To enter a number press N or n \n");
printf("Enter 1 to print triangle type 1(left justified): \n");
printf("Enter 2 to print triangle type 2(right justified): \n");
printf("Quit program with q or Q \n");
}
//end printMenu
char menuSelect()
{
char choice;
scanf(" %c",&choice);
return choice;
}
//end menuSelect

char enterChar()
{
char c = ' ';
printf("This is function enterChar() \n");
printf("Please enter a character: \n");
scanf(" %c",&c);
return c;
}
//end enterChar

int enterInt()
{
int n = 0;
printf("This is function enterInt() \n");
do
{
printf("Enter a number between 1 and 15 \n");
scanf(" %d",&n);
}
while(n > 15 || n < 1);
return n;
}
//end enterInt()

void leftTriangle(int N, char C)
{
int count;
int current=0;
char letter[N];
printf("This is function leftTriangle() \n");
for(count = 0; count <  N+1; count++)
{
letter[count]=C;
do
{
current++;
printf( "%c", letter[current]);
}
while(current<count);
current = 0;
printf("\n");

}
}
//end leftTriangle

void rightTriangle(int N, char C)
{
int count;
int current=0;
char letter[N];
char space[N];
printf("This is function rightTriangle() \n");
for(count = 0; count < N; count++)
{
space[count] = ' ';
letter[count] = C;
}
for(count=0;count<N;count++)
{
while(current<(N-count-1))
{
current++;
printf("%c",space[count]);
}
current = 0;
do
{
current++;
printf("%c",letter[count]);
}
while(current<count+1);
printf("\n");
current = 0;
}
}
//end rightTriangle

int main()
{
char choice = ' ';
char C = ' ';
int N = 0;

do
{
printMenu();
choice = menuSelect();

switch(choice)
{
case '1':
leftTriangle(N,C);
break;

case '2':
rightTriangle(N,C);
break;

case 'c':
C = enterChar();
break;

case 'C':
C = enterChar();
break;

case 'n':
N = enterInt();
break;

case 'N':
N = enterInt();
break;

case 'q':
printf("Goodbye \n");
break;

case 'Q':
printf("Goodbye \n");
break;

default:
printf("Not a listed choice, Try again \n");
break;
}
if(choice == 'q')
break;
else if(choice == 'Q')
break;
}
while(choice != 'q' || choice != 'Q');
return 0;
}
//end Main
