//Brian Anderson G00986738
//CS 262, Lab Section 210
//Lab 11
#include <stdio.h>
#include <stdlib.h>
//Macro for printing bit values
#define BYTETOBINARYPATTERN "%d%d%d%d%d%d%d%d"

#define BYTETOBINARY(byte) \
(byte & 0x80 ? 1 : 0), \
(byte & 0x40 ? 1 : 0), \
(byte & 0x20 ? 1 : 0), \
(byte & 0x10 ? 1 : 0), \
(byte & 0x08 ? 1 : 0), \
(byte & 0x04 ? 1 : 0), \
(byte & 0x02 ? 1 : 0), \
(byte & 0x01 ? 1 : 0)

#define PRINTBIN(x) printf(BYTETOBINARYPATTERN, BYTETOBINARY(x));
//set the least significant bits of an array to the bits of b0
void setlsbs(unsigned char *p, unsigned char b0)
{
	int i;
	int lbs[8];
	int bs[8];
	int tmp[8];
	//initialize arrays
	for(i=0;i<8;i++)
	{
		lbs[i]= p[i]&1;
		bs[i] = (b0>>i)&1;	
	}
	//clear bits of p[i]
	for(i=0;i<8;i++)
	{
		p[i] = p[i]+lbs[i];	
		tmp[i] = bs[7-i];	
	}
	//set bits from b0
	for(i=0;i<8;i++)
	{
		p[i] = p[i]|tmp[i];
	}	
	
}
//return a byte value given an array of unsigned chars
unsigned char getlsbs(unsigned char *p)
{
	unsigned char b;
	int i;
	int lbs[8];
	//get values of lsbs in array p and add them to byte b
	for(i=0;i<8;i++)
	{
		
		lbs[i] = p[i]&1;	
		b<<=1;
		b |= lbs[i];
	}
	return b;
}

int main(int argc, char *argv[])
{
int i;				//counter
int seed = atoi(argv[1]);	//seed
srandom(seed);			//generate random
unsigned char ch;
unsigned char p[8];
unsigned char byte0;

//random number byte
byte0 = random();

//create random number array between 0 and 255
for(i=0;i<8;i++)
{
p[i] = random()%255;
}

printf("Original Array \n");

//print original array
for(i=0;i<8;i++)
{
printf(" %d ",p[i]);
PRINTBIN(p[i]);
printf("\n");
}

//print byte
printf("Byte: %d ",byte0);
PRINTBIN(byte0);
printf("\n");

//set lsbs to byte0
setlsbs(p,byte0);

printf("Modified Array \n");

//print modified array
for(i=0;i<8;i++)
{
printf(" %d ",p[i]);
PRINTBIN(p[i]);
printf("\n");
}

//get byte0 back from modified array
ch = getlsbs(p);

//print byte0
printf("Return Byte: %d ",ch);
PRINTBIN(ch);
printf("\n");

return 0;
}
