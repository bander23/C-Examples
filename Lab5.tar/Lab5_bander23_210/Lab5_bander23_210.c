//Brian Anderson G00986738
//CS 262, Lab Section 210
//Lab5

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *input;
	FILE *output;
//opens input and output file for read and write respectively
	input = fopen(argv[1], "r");
	assert(input != NULL);
	output = fopen("OutputFile","w");
//loop to go through file and read and copy info to output until eof
	do
	{
		char myChar = fgetc(input);
		if(!feof(input))
			fprintf(output,"%c", myChar);
	//check to see if program is working when debugging
		#ifndef NDEBUG
		printf("%c", myChar);
		#endif

	}
	while(!feof(input));
//closes files
	fclose(input);
	fclose(output);

	return 0;
}
