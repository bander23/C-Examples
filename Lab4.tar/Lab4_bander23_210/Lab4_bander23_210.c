//Brian Anderson G00986738
//CS 262, Lab Section 210
//Lab4
#include <stdlib.h>
#include <stdio.h>

#define RNG_SEED 986738
#define ARRAY_SIZE 20
#define NUM_LOOPS 10

void initializeArray(int *numArray, const int arrayLength)
{
int count;
for(count=0;count<ARRAY_SIZE;count++)
{
numArray[count]=1;
}
}

void printArray(int array[])
{
int count;
for(count=0;count<ARRAY_SIZE;count++)
{
if(count>40)
{
printf("\n");
}
printf("%d", array[count]);
printf(" ");
}
printf("\n");
}

int shuffleArray(int *numArray,const int arrayLength)
{
int count;
int my_random_val;
for(count=0;count<ARRAY_SIZE;count++)
{
my_random_val = random()%(count+1);
numArray[count] = my_random_val;
}
return 0;
}

int main()
{
srandom(RNG_SEED);
printf("My name is Brian Anderson.\n I'm in lab section 210. This program will be creating an array of random numbers and printing them out.\n");
int numArray[ARRAY_SIZE];
int count;
for(count=0;count<NUM_LOOPS;count++)
{
initializeArray(numArray,ARRAY_SIZE);
printArray(numArray);
shuffleArray(numArray,ARRAY_SIZE);
printArray(numArray);
}
return 0;
}

