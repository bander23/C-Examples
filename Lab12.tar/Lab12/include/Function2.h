#ifndef FUNCTION2_H
#define FUNCTION2_H

void Function2();

#endif

